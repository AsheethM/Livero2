<?php
header("Access-Control-Allow-Origin: *");
$servername = "localhost";
$username = "pri_user";
$password = "waswas1";
$dbname = "pri_data";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "UPDATE gps SET latitude='".$_POST["latitude"]."',  longitude='".$_POST["longitude"]."',  altitude='".$_POST["altitude"]."',accuracy='".$_POST["accuracy"]."',speed='".$_POST["speed"]."',heading='".$_POST["heading"]."' WHERE session_id='happy'";


if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>

