<?php

$val = $_POST["val1"];
$array1 = array($val,"happy","halloween");









print json_encode($array1);
?>