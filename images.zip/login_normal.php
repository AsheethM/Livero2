<?php
header("Access-Control-Allow-Origin: *");


$servername = "localhost";
$username = "pri_user";
$password = "waswas1";
$dbname = "pri_data";

$password_md5 = md5($_POST["password"]); 
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "select email from user where email='".$_POST["email"]."' AND  password='".$password_md5."'";
$result = $conn->query($sql);
$conn->close();
if (null != $result && mysqli_num_rows($result) >= 1)
{
print json_encode(1);
}
else
{
print json_encode(0);
}
?>