<?php
header("Access-Control-Allow-Origin: *");
$servername = "localhost";
$username = "pri_user";
$password = "waswas1";
$dbname = "pri_data";
$lat = array();
$long = array();
$name = array();
$logos = array();
$id = array();

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


  
$sql  = "SELECT email,name,logo, latitude, longitude, SQRT(
POW(69.1 * (latitude - ".$_POST["latitude"]."), 2) +
POW(69.1 * (".$_POST["longitude"]." - longitude) * COS(latitude / 57.3), 2)) AS distance
FROM vendor HAVING distance < ".$_POST["distance"]." ORDER BY distance";
  
 
    $result =  mysqli_query($conn, $sql);
 
 
 
 
 while ($row = mysqli_fetch_array($result))
{
      $lat[]= $row['latitude'];         
      $long[] = $row['longitude'];
      $name[] = $row['name'];
      $logos[]= $row['logo'];
      $id[]= $row['email'];

 } 
  $conn->close();

$results = array(
  "latitude" => $lat,
  "longitude" => $long,
  "name" => $name,
  "logos" => $logos,
"id" => $id
    );


    
print json_encode ($results);
?>