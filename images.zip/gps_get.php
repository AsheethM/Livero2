<?php
header("Access-Control-Allow-Origin: *");
$servername = "localhost";
$username = "pri_user";
$password = "waswas1";
$dbname = "pri_data";
$results = array();


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT *  FROM gps where session_id = 'happy'";
    $result =  mysqli_query($conn, $sql);
 while ($row = mysqli_fetch_array($result))
{
    $results[]= $row['latitude'];
    $results[]= $row['longitude'];
    $results[]= $row['speed'];
    $results[]= $row['altitude'];
    $results[]= $row['accuracy'];
                
 } 
  $conn->close();
  /*
$results = array(
  "latitude" => $latitude,
   "longitude" => $longitude,
   "speed" => $speed,
   "altitude" => $altitude,
   "accuracy" => $accuracy,
    );
 */
    
print json_encode ($results);
?>